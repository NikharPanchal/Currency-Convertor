package com.example.currencyconvert;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.media.Image;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;


public class CurrencyActivity extends AppCompatActivity {

    Button btn;
    EditText user_input;
    Spinner spinner_from;
    Spinner spinner_to;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_currency);

        btn=findViewById(R.id.button);
        user_input=findViewById(R.id.editTextNumberSigned8);
        spinner_from=findViewById(R.id.spinner1);
        spinner_to=findViewById(R.id.spinner2);

        ImageView swap= (ImageView) findViewById(R.id.swapbtn);

        Spinner dropDown =(Spinner) findViewById(R.id.spinner1);
        String items[]=new String[]{"AUD:Australian Dollar","CAD:Canadian Dollar","CNY:Chinese Yuan","EUR:Euro","INR:Indian Rupee","MXN:Mexican Peso","RUB:Russian Ruble","SGD:Singapore Dollar","USD:United State Dollar","ZAR:South African Rand"};
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,items);
        dropDown.setAdapter(adapter);

        Spinner dropDown2 =(Spinner) findViewById(R.id.spinner2);
        String items2[]=new String[]{"AUD:Australian Dollar","CAD:Canadian Dollar","CNY:Chinese Yuan","EUR:Euro","INR:Indian Rupee","MXN:Mexican Peso","RUB:Russian Ruble","SGD:Singapore Dollar","USD:United State Dollar","ZAR:South African Rand"};
        ArrayAdapter<String> adapter2=new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,items2);
        dropDown2.setAdapter(adapter2);

        swap.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                int positionSpinner1 = spinner_from.getSelectedItemPosition() ;
                int positionSpinner2 = spinner_to.getSelectedItemPosition() ;
                if (spinner_from.getAdapter().equals(adapter)) {
                    spinner_from.setAdapter(adapter2);
                    spinner_to.setAdapter(adapter);
                } else {
                    spinner_from.setAdapter(adapter);
                    spinner_to.setAdapter(adapter2);
                }
                spinner_from.setSelection(positionSpinner2);
                spinner_to.setSelection(positionSpinner1);
            }
        });


        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (user_input.getText().toString().isEmpty() ||Integer.parseInt(user_input.getText().toString()) <= 0) {
                    Toast.makeText( CurrencyActivity.this, "Enter valid input...", Toast.LENGTH_SHORT).show();
                }
                else {

                    double convert_val;
                    double amount = Double.parseDouble(user_input.getText().toString());

                    /*Australian dollar to other currency*/
                    if (spinner_from.getSelectedItem().toString() == "AUD:Australian Dollar" && spinner_to.getSelectedItem().toString() == "CAD:Canadian Dollar") {
                        convert_val = amount * 0.888;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    }else if (spinner_from.getSelectedItem().toString() == "AUD:Australian Dollar" && spinner_to.getSelectedItem().toString() == "AUD:Australian Dollar") {
                        convert_val = amount * 4.7358;
                        Toast.makeText( CurrencyActivity.this, "Enter different input", Toast.LENGTH_SHORT).show();
                    }
                    else if (spinner_from.getSelectedItem().toString() == "AUD:Australian Dollar" && spinner_to.getSelectedItem().toString() == "CNY:Chinese Yuan") {
                        convert_val = amount * 4.7358;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "AUD:Australian Dollar" && spinner_to.getSelectedItem().toString() == "EUR:Euro") {
                        convert_val = amount * 0.6450;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "AUD:Australian Dollar" && spinner_to.getSelectedItem().toString() == "INR:Indian Rupee") {
                        convert_val = amount * 54.1094;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "AUD:Australian Dollar" && spinner_to.getSelectedItem().toString() == "MXN:Mexican Peso") {
                        convert_val = amount * 12.9175;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "AUD:Australian Dollar" && spinner_to.getSelectedItem().toString() == "RUB:Russian Ruble") {
                        convert_val = amount * 40.2406;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "AUD:Australian Dollar" && spinner_to.getSelectedItem().toString() == "SGD:Singapore Dollar") {
                        convert_val = amount * 0.9150;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "AUD:Australian Dollar" && spinner_to.getSelectedItem().toString() == "USD:United State Dollar") {
                        convert_val = amount * 0.6637;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "AUD:Australian Dollar" && spinner_to.getSelectedItem().toString() == "ZAR:South African Rand") {
                        convert_val = amount * 11.4651;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    }

                    /*Canadian Dollar to other currency*/
                    else if (spinner_from.getSelectedItem().toString() == "CAD:Canadian Dollar" && spinner_to.getSelectedItem().toString() == "AUD:Australian Dollar") {
                        convert_val = amount * 1.1253;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    }
                    else if (spinner_from.getSelectedItem().toString() == "CAD:Canadian Dollar" && spinner_to.getSelectedItem().toString() == "CAD:Canadian Dollar") {
                        convert_val = amount * 4.7358;
                        Toast.makeText( CurrencyActivity.this, "Enter different input", Toast.LENGTH_SHORT).show();
                    }
                    else if (spinner_from.getSelectedItem().toString() == "CAD:Canadian Dollar" && spinner_to.getSelectedItem().toString() == "CNY:Chinese Yuan") {
                        convert_val = amount * 5.3255;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "CAD:Canadian Dollar" && spinner_to.getSelectedItem().toString() == "EUR:Euro") {
                        convert_val = amount * 0.7260;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "CAD:Canadian Dollar" && spinner_to.getSelectedItem().toString() == "INR:Indian Rupee") {
                        convert_val = amount * 60.9422;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "CAD:Canadian Dollar" && spinner_to.getSelectedItem().toString() == "MXN:Mexican Peso") {
                        convert_val = amount * 14.5108;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "CAD:Canadian Dollar" && spinner_to.getSelectedItem().toString() == "RUB:Russian Ruble") {
                        convert_val = amount * 45.2225;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "CAD:Canadian Dollar" && spinner_to.getSelectedItem().toString() == "SGD:Singapore Dollar") {
                        convert_val = amount * 1.0287;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "CAD:Canadian Dollar" && spinner_to.getSelectedItem().toString() == "USD:United State Dollar") {
                        convert_val = amount * 0.6637;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "CAD:Canadian Dollar" && spinner_to.getSelectedItem().toString() == "ZAR:South African Rand") {
                        convert_val = amount * 12.8908;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    }

                    /*Chinese Yuan to other currency*/
                    else if (spinner_from.getSelectedItem().toString() == "CNY:Chinese Yuan" && spinner_to.getSelectedItem().toString() == "AUD:Australian Dollar") {
                        convert_val = amount * 0.2111;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "CNY:Chinese Yuan" && spinner_to.getSelectedItem().toString() == "CNY:Chinese Yuan") {
                        convert_val = amount * 4.7358;
                        Toast.makeText( CurrencyActivity.this, "Enter different input", Toast.LENGTH_SHORT).show();
                    }
                    else if (spinner_from.getSelectedItem().toString() == "CNY:Chinese Yuan" && spinner_to.getSelectedItem().toString() == "CAD:Canadian Dollar") {
                        convert_val = amount * 0.1877;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "CNY:Chinese Yuan" && spinner_to.getSelectedItem().toString() == "EUR:Euro") {
                        convert_val = amount * 0.1363;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "CNY:Chinese Yuan" && spinner_to.getSelectedItem().toString() == "INR:Indian Rupee") {
                        convert_val = amount * 11.4464;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "CNY:Chinese Yuan" && spinner_to.getSelectedItem().toString() == "MXN:Mexican Peso") {
                        convert_val = amount * 2.7244;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "CNY:Chinese Yuan" && spinner_to.getSelectedItem().toString() == "RUB:Russian Ruble") {
                        convert_val = amount * 8.5615;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "CNY:Chinese Yuan" && spinner_to.getSelectedItem().toString() == "SGD:Singapore Dollar") {
                        convert_val = amount * 0.1933;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "CNY:Chinese Yuan" && spinner_to.getSelectedItem().toString() == "USD:United State Dollar") {
                        convert_val = amount * 0.1401;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "CNY:Chinese Yuan" && spinner_to.getSelectedItem().toString() == "ZAR:South African Rand") {
                        convert_val = amount * 2.4198;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    }

                    /*EUR:Euro to other currency*/
                    else if (spinner_from.getSelectedItem().toString() == "EUR:Euro" && spinner_to.getSelectedItem().toString() == "AUD:Australian Dollar") {
                        convert_val = amount * 1.5491;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    }
                    else if (spinner_from.getSelectedItem().toString() == "EUR:Euro" && spinner_to.getSelectedItem().toString() == "EUR:Euro") {
                        convert_val = amount * 4.7358;
                        Toast.makeText( CurrencyActivity.this, "Enter different input", Toast.LENGTH_SHORT).show();
                    }
                    else if (spinner_from.getSelectedItem().toString() == "EUR:Euro" && spinner_to.getSelectedItem().toString() == "CAD:Canadian Dollar") {
                        convert_val = amount * 1.3765;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "EUR:Euro" && spinner_to.getSelectedItem().toString() == "CNY:Chinese Yuan") {
                        convert_val = amount * 7.3377;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "EUR:Euro" && spinner_to.getSelectedItem().toString() == "INR:Indian Rupee") {
                        convert_val = amount * 83.9321;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "EUR:Euro" && spinner_to.getSelectedItem().toString() == "MXN:Mexican Peso") {
                        convert_val = amount * 19.9798;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "EUR:Euro" && spinner_to.getSelectedItem().toString() == "RUB:Russian Ruble") {
                        convert_val = amount * 62.3199;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "EUR:Euro" && spinner_to.getSelectedItem().toString() == "SGD:Singapore Dollar") {
                        convert_val = amount * 1.4173;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "EUR:Euro" && spinner_to.getSelectedItem().toString() == "USD:United State Dollar") {
                        convert_val = amount * 1.0275;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "EUR:Euro" && spinner_to.getSelectedItem().toString() == "ZAR:South African Rand") {
                        convert_val = amount * 17.7503;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    }

                    /*INR:Indian Rupee to other currency*/
                    else if (spinner_from.getSelectedItem().toString() == "INR:Indian Rupee" && spinner_to.getSelectedItem().toString() == "AUD:Australian Dollar") {
                        convert_val = amount * 0.0185;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    }
                    else if (spinner_from.getSelectedItem().toString() == "INR:Indian Rupee" && spinner_to.getSelectedItem().toString() == "INR:Indian Rupee") {
                        convert_val = amount * 4.7358;
                        Toast.makeText( CurrencyActivity.this, "Enter different input", Toast.LENGTH_SHORT).show();
                    }
                    else if (spinner_from.getSelectedItem().toString() == "INR:Indian Rupee" && spinner_to.getSelectedItem().toString() == "CAD:Canadian Dollar") {
                        convert_val = amount * 0.0164;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "INR:Indian Rupee" && spinner_to.getSelectedItem().toString() == "CNY:Chinese Yuan") {
                        convert_val = amount * 0.0874;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "INR:Indian Rupee" && spinner_to.getSelectedItem().toString() == "EUR:Euro") {
                        convert_val = amount * 0.0119;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "INR:Indian Rupee" && spinner_to.getSelectedItem().toString() == "MXN:Mexican Peso") {
                        convert_val = amount * 0.2380;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "INR:Indian Rupee" && spinner_to.getSelectedItem().toString() == "RUB:Russian Ruble") {
                        convert_val = amount * 0.7425;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "INR:Indian Rupee" && spinner_to.getSelectedItem().toString() == "SGD:Singapore Dollar") {
                        convert_val = amount * 0.0169;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "INR:Indian Rupee" && spinner_to.getSelectedItem().toString() == "USD:United State Dollar") {
                        convert_val = amount * 0.0122;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "INR:Indian Rupee" && spinner_to.getSelectedItem().toString() == "ZAR:South African Rand") {
                        convert_val = amount * 0.2114;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    }

                    /*MXN:Mexican Peso to other currency*/
                    else if (spinner_from.getSelectedItem().toString() == "MXN:Mexican Peso" && spinner_to.getSelectedItem().toString() == "AUD:Australian Dollar") {
                        convert_val = amount * 0.0775;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    }
                    else if (spinner_from.getSelectedItem().toString() == "MXN:Mexican Peso" && spinner_to.getSelectedItem().toString() == "MXN:Mexican Peso") {
                        convert_val = amount * 4.7358;
                        Toast.makeText( CurrencyActivity.this, "Enter different input", Toast.LENGTH_SHORT).show();
                    }
                    else if (spinner_from.getSelectedItem().toString() == "MXN:Mexican Peso" && spinner_to.getSelectedItem().toString() == "CAD:Canadian Dollar") {
                        convert_val = amount * 0.0689;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "MXN:Mexican Peso" && spinner_to.getSelectedItem().toString() == "CNY:Chinese Yuan") {
                        convert_val = amount * 0.3671;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "MXN:Mexican Peso" && spinner_to.getSelectedItem().toString() == "EUR:Euro") {
                        convert_val = amount * 0.0501;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "MXN:Mexican Peso" && spinner_to.getSelectedItem().toString() == "INR:Indian Rupee") {
                        convert_val = amount * 4.2011;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "MXN:Mexican Peso" && spinner_to.getSelectedItem().toString() == "RUB:Russian Ruble") {
                        convert_val = amount * 3.1192;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "MXN:Mexican Peso" && spinner_to.getSelectedItem().toString() == "SGD:Singapore Dollar") {
                        convert_val = amount * 0.0709;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "MXN:Mexican Peso" && spinner_to.getSelectedItem().toString() == "USD:United State Dollar") {
                        convert_val = amount * 0.0514;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "MXN:Mexican Peso" && spinner_to.getSelectedItem().toString() == "ZAR:South African Rand") {
                        convert_val = amount * 0.8887;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    }

                    /*RUB:Russian Ruble to other currency*/
                    else if (spinner_from.getSelectedItem().toString() == "RUB:Russian Ruble" && spinner_to.getSelectedItem().toString() == "AUD:Australian Dollar") {
                        convert_val = amount * 0.0249;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    }

                    else if (spinner_from.getSelectedItem().toString() == "RUB:Russian Ruble" && spinner_to.getSelectedItem().toString() == "RUB:Russian Ruble") {
                        convert_val = amount * 4.7358;
                        Toast.makeText( CurrencyActivity.this, "Enter different input", Toast.LENGTH_SHORT).show();
                    }
                    else if (spinner_from.getSelectedItem().toString() == "RUB:Russian Ruble" && spinner_to.getSelectedItem().toString() == "CAD:Canadian Dollar") {
                        convert_val = amount * 0.221;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "RUB:Russian Ruble" && spinner_to.getSelectedItem().toString() == "CNY:Chinese Yuan") {
                        convert_val = amount * 0.1177;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "RUB:Russian Ruble" && spinner_to.getSelectedItem().toString() == "EUR:Euro") {
                        convert_val = amount * 0.0160;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "RUB:Russian Ruble" && spinner_to.getSelectedItem().toString() == "INR:Indian Rupee") {
                        convert_val = amount * 1.3468;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "RUB:Russian Ruble" && spinner_to.getSelectedItem().toString() == "MXN:Mexican Peso") {
                        convert_val = amount * 0.3203;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "RUB:Russian Ruble" && spinner_to.getSelectedItem().toString() == "SGD:Singapore Dollar") {
                        convert_val = amount * 0.0227;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "RUB:Russian Ruble" && spinner_to.getSelectedItem().toString() == "USD:United State Dollar") {
                        convert_val = amount * 0.0165;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "RUB:Russian Ruble" && spinner_to.getSelectedItem().toString() == "ZAR:South African Rand") {
                        convert_val = amount * 0.2845;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    }

                    /*SGD:Singapore Dollar to other currency*/
                    else if (spinner_from.getSelectedItem().toString() == "SGD:Singapore Dollar" && spinner_to.getSelectedItem().toString() == "AUD:Australian Dollar") {
                        convert_val = amount * 1.0928;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    }
                    else if (spinner_from.getSelectedItem().toString() == "SGD:Singapore Dollar" && spinner_to.getSelectedItem().toString() == "SGD:Singapore Dollar") {
                        convert_val = amount * 4.7358;
                        Toast.makeText( CurrencyActivity.this, "Enter different input", Toast.LENGTH_SHORT).show();
                    }
                    else if (spinner_from.getSelectedItem().toString() == "SGD:Singapore Dollar" && spinner_to.getSelectedItem().toString() == "CAD:Canadian Dollar") {
                        convert_val = amount * 0.9711;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "SGD:Singapore Dollar" && spinner_to.getSelectedItem().toString() == "CNY:Chinese Yuan") {
                        convert_val = amount * 5.1771;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "SGD:Singapore Dollar" && spinner_to.getSelectedItem().toString() == "EUR:Euro") {
                        convert_val = amount * 0.7048;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "SGD:Singapore Dollar" && spinner_to.getSelectedItem().toString() == "INR:Indian Rupee") {
                        convert_val = amount * 59.2319;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "SGD:Singapore Dollar" && spinner_to.getSelectedItem().toString() == "MXN:Mexican Peso") {
                        convert_val = amount * 14.0935;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "SGD:Singapore Dollar" && spinner_to.getSelectedItem().toString() == "RUB:Russian Ruble") {
                        convert_val = amount * 43.9912;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "SGD:Singapore Dollar" && spinner_to.getSelectedItem().toString() == "USD:United State Dollar") {
                        convert_val = amount * 0.0165;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "SGD:Singapore Dollar" && spinner_to.getSelectedItem().toString() == "ZAR:South African Rand") {
                        convert_val = amount * 12.5215;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    }

                    /*USD:United State Dollar to other currency*/
                    else if (spinner_from.getSelectedItem().toString() == "USD:United State Dollar" && spinner_to.getSelectedItem().toString() == "AUD:Australian Dollar") {
                        convert_val = amount * 1.0928;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    }

                    else if (spinner_from.getSelectedItem().toString() == "USD:United State Dollar" && spinner_to.getSelectedItem().toString() == "USD:United State Dollar") {
                        convert_val = amount * 4.7358;
                        Toast.makeText( CurrencyActivity.this, "Enter different input", Toast.LENGTH_SHORT).show();
                    }
                    else if (spinner_from.getSelectedItem().toString() == "USD:United State Dollar" && spinner_to.getSelectedItem().toString() == "CAD:Canadian Dollar") {
                        convert_val = amount * 0.9711;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "USD:United State Dollar" && spinner_to.getSelectedItem().toString() == "CNY:Chinese Yuan") {
                        convert_val = amount * 5.1771;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "USD:United State Dollar" && spinner_to.getSelectedItem().toString() == "EUR:Euro") {
                        convert_val = amount * 0.7048;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "USD:United State Dollar" && spinner_to.getSelectedItem().toString() == "INR:Indian Rupee") {
                        convert_val = amount * 59.2319;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "USD:United State Dollar" && spinner_to.getSelectedItem().toString() == "MXN:Mexican Peso") {
                        convert_val = amount * 14.0935;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "USD:United State Dollar" && spinner_to.getSelectedItem().toString() == "RUB:Russian Ruble") {
                        convert_val = amount * 43.9912;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "USD:United State Dollar" && spinner_to.getSelectedItem().toString() == "SGD:Singapore Dollar") {
                        convert_val = amount * 0.0165;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "USD:United State Dollar" && spinner_to.getSelectedItem().toString() == "ZAR:South African Rand") {
                        convert_val = amount * 12.5215;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    }

                    /*ZAR:South African Rand to other currency*/
                    else if (spinner_from.getSelectedItem().toString() == "ZAR:South African Rand" && spinner_to.getSelectedItem().toString() == "AUD:Australian Dollar") {
                        convert_val = amount * 1.0928;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    }

                    else if (spinner_from.getSelectedItem().toString() == "ZAR:South African Rand" && spinner_to.getSelectedItem().toString() == "ZAR:South African Rand") {
                        convert_val = amount * 4.7358;
                        Toast.makeText( CurrencyActivity.this, "Enter different input", Toast.LENGTH_SHORT).show();
                    }
                    else if (spinner_from.getSelectedItem().toString() == "ZAR:South African Rand" && spinner_to.getSelectedItem().toString() == "CAD:Canadian Dollar") {
                        convert_val = amount * 0.9711;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "ZAR:South African Rand" && spinner_to.getSelectedItem().toString() == "CNY:Chinese Yuan") {
                        convert_val = amount * 5.1771;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "ZAR:South African Rand" && spinner_to.getSelectedItem().toString() == "EUR:Euro") {
                        convert_val = amount * 0.7048;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "ZAR:South African Rand" && spinner_to.getSelectedItem().toString() == "INR:Indian Rupee") {
                        convert_val = amount * 59.2319;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "ZAR:South African Rand" && spinner_to.getSelectedItem().toString() == "MXN:Mexican Peso") {
                        convert_val = amount * 14.0935;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "ZAR:South African Rand" && spinner_to.getSelectedItem().toString() == "RUB:Russian Ruble") {
                        convert_val = amount * 43.9912;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "ZAR:South African Rand" && spinner_to.getSelectedItem().toString() == "SGD:Singapore Dollar") {
                        convert_val = amount * 0.0165;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    } else if (spinner_from.getSelectedItem().toString() == "ZAR:South African Rand" && spinner_to.getSelectedItem().toString() == "USD:United State Dollar") {
                        convert_val = amount * 12.5215;
                        Toast.makeText(getApplicationContext(), String.valueOf(convert_val), Toast.LENGTH_LONG).show();
                    }
                }
            }
        });
    }
}